module lab3_1(
    input wire clk,
    input wire rst,
    output reg test_led9,
    output wire tx,
    input wire rx
);

reg [31:0] cnt;
wire clr_cnt;
wire txclk_en;
wire rxclk_en;
wire [7:0] dout;
wire rdy;

assign clr_cnt = (cnt == 32'd25_000_000);

always @(posedge clk or negedge rst) begin
    if(!rst) cnt <= 32'h0;
    else if(clr_cnt) cnt <= 32'h0;
    else cnt <= cnt + 32'h1;
end

always @(posedge clk or negedge rst) begin
    if(!rst) test_led9 <= 1'b0;
    else if (clr_cnt) test_led9 <= ~test_led9;
end

baud_rate_gen uart_baud(.clk_50m(clk), .rxclk_en(rxclk_en), .txclk_en(txclk_en));
transmitter uart_tx(.din(dout), .wr_en(rdy), .clk_50m(clk), .clken(txclk_en), .tx(tx));
receiver uart_rx(.rx(rx), .rdy(rdy), .rdy_clr(rdy), .clk_50m(clk), .clken(rxclk_en), .data(dout));
//uart m_uart(.din(8'h40), .wr_en(clr_cnt), .clk_50m(clk), .tx(tx));

endmodule